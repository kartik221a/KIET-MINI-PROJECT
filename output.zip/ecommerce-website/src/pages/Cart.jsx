// src/pages/Cart.jsx
import React, { useState, useEffect } from 'react';

const Cart = () => {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const storedCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCart(storedCart);
  }, []);

  const removeFromCart = (productId) => {
    const updatedCart = cart.filter((item) => item.id !== productId);
    setCart(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="cart">
      <h1 className="cart__title">Your Shopping Cart</h1>
      {cart.length > 0 ? (
        <div>
          {cart.map((item) => (
            <div key={item.id} className="cart-item">
              <h2 className="cart-item__name">{item.name}</h2>
              <p className="cart-item__price">Price: ${item.price}</p>
              <button className="cart-item__button" onClick={() => removeFromCart(item.id)}>
                Remove
              </button>
            </div>
          ))}
          <h3 className="cart__total">Total: ${total}</h3>
        </div>
      ) : (
        <p className="cart__empty-message">Your cart is empty!</p>
      )}
    </div>
  );
};

export default Cart;
