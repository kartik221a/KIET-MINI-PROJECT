// src/pages/Home.jsx
import React from 'react';

const Home = () => {
  const products = [
    { id: 1, name: 'Product 1', price: 100 },
    { id: 2, name: 'Product 2', price: 200 },
    { id: 3, name: 'Product 3', price: 300 },
  ];

  const addToCart = (product) => {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`${product.name} added to cart!`);
  };

  return (
    <div className="home">
      <h1 className="home__title">Welcome to Our Store</h1>
      <div className="home__products">
        {products.map((product) => (
          <div key={product.id} className="product-card">
            <h2 className="product-card__name">{product.name}</h2>
            <p className="product-card__price">Price: ${product.price}</p>
            <button className="product-card__button" onClick={() => addToCart(product)}>
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;
