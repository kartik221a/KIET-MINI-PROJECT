// src/App.jsx
import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Home from './pages/Home';
import Cart from './pages/Cart';
import './App.css';

const App = () => {
  return (
    <Router>
      <nav className="navbar">
        <Link className="navbar__link" to="/">Home</Link>
        <Link className="navbar__link" to="/cart">Cart</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/cart" element={<Cart />} />
      </Routes>
    </Router>
  );
};

export default App;

// npm install react-router-dom
